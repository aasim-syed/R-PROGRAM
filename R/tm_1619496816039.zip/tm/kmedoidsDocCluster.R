library(fpc)
setwd("G:\\phd\\work\\R work\\")

docs<- Corpus(DirSource("G:\\phd\\work\\R work\\DataSet\\my"))

dtm <- DocumentTermMatrix(docs)
dtm.matrix <- as.matrix(dtm) 
m <- as.matrix(dtm)

pamResult <- pamk(m, metric="manhattan")

k <- pamResult$nc
pamResult <- pamResult$pamobject