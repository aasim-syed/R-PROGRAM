library(fpc)
library(tm)

setwd("G:\\phd\\work\\R work\\")

docs<- Corpus(DirSource("G:\\phd\\work\\R work\\DataSet\\my"))

tdm <-TermDocumentMatrix(docs)
tdm<-removeSparseTerms(tdm, sparse=0.8)
tdm.matrix <- as.matrix(tdm) 
m <- as.matrix(tdm)

distMatrix<-dist(m)

fit <- hclust(distMatrix)
plot(fit)
