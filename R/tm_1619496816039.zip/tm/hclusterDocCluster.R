library(fpc)
setwd("G:\\phd\\work\\R work\\")

docs<- Corpus(DirSource("G:\\phd\\work\\R work\\DataSet\\my"))

dtm <- DocumentTermMatrix(docs)
dtm.matrix <- as.matrix(dtm) 
m <- as.matrix(dtm)


distMatrix<-dist(m)

fit <- hclust(distMatrix)

plot(fit)
