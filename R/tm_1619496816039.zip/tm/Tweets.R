library(twitteR)
thiruTweets<-userTimeline("sachin",n=200)

